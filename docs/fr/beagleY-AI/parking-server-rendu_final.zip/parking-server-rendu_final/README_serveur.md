# Serveur Cloud & Backend (Render / Flask)

Ce dossier contient le code et la procédure de déploiement du serveur central du projet **Parking Monitoring System**.

Le serveur agit comme le chef d’orchestre.  
Il héberge la base de données PostgreSQL, gère les paiements via Stripe, fournit l’interface Web d’administration et relaie les ordres entre l’utilisateur et le microcontrôleur STM32 via MQTT.

## Prérequis

Avant de commencer, il est nécessaire de créer des comptes sur les services suivants.  
Les versions gratuites sont suffisantes.

- GitHub  
- Render.com  
- HiveMQ Cloud  
- Stripe  
- OpenWeatherMap  
- Telegram  
- Tailscale  

## Étape 1 : Préparation du code (GitHub)

Créer un dépôt privé sur GitHub, par exemple `parking-server`.

Structurer le dépôt comme suit puis pousser l’ensemble des fichiers :

```
/parking-server
├── templates/           Fichiers HTML
├── static/              CSS, JavaScript et images
├── serveur.py           Code principal Flask
├── config.py            Configuration
├── b2b.py               Module devis B2B
├── extensions.py        Base de données et SocketIO
├── requirements.txt     Dépendances Python
└── meteo_client.py      Script météo local
```

## Contenu obligatoire de `requirements.txt`

```
Flask
paho-mqtt
gunicorn
requests
stripe
pytz
Flask-SQLAlchemy
psycopg2-binary
Flask-SocketIO
gevent
gevent-websocket
```

## Étape 2 : Génération des clés API

Toutes les clés doivent être récupérées avant la configuration du serveur.

### Broker MQTT – HiveMQ Cloud

Créer un cluster gratuit.  
Créer un utilisateur dédié.  
Noter l’adresse du cluster, le port TLS `8883` et le mot de passe.

### Stripe – Paiements

Récupérer la **Secret Key** (`sk_test_...`).  
Ajouter un webhook vers :

```
https://<app-render>.onrender.com/api/stripe_webhook
```

Récupérer le **Webhook Secret** (`whsec_...`).

### Telegram – Notifications

Créer un bot via **@BotFather**.  
Récupérer le **Bot Token**.  
Envoyer un message au bot.  
Récupérer le **Chat ID** via :

```
https://api.telegram.org/bot<VOTRE_TOKEN>/getUpdates
```

## Étape 3 : Base de données (Render)

Créer une base PostgreSQL sur Render.

Nom : `parking-db`  
Région : Frankfurt (EU Central)  
Plan : Free  

Copier l’**Internal Database URL**.

## Étape 4 : Déploiement du serveur Web (Render)

Créer un **Web Service** sur Render.  
Connecter le dépôt GitHub `parking-server`.

### Build Command

```
pip install -r requirements.txt
```

### Start Command

```
gunicorn -k geventwebsocket.gunicorn.workers.GeventWebSocketWorker -w 1 serveur:app
```

## Étape 5 : Variables d’environnement

Configurer les variables suivantes sur Render :

```
PYTHON_VERSION
FLASK_SECRET
DATABASE_URL
MQTT_HOST
MQTT_PORT
MQTT_SECRET
ADMIN_USER
ADMIN_PASSWORD
STRIPE_API_KEY
STRIPE_WEBHOOK_SECRET
TELEGRAM_BOT_TOKEN
TELEGRAM_CHAT_ID
NGROK_BASE
```

## Étape 6 : Connexion locale (Tailscale)

Installer Tailscale sur la machine locale.  
Activer le tunnel sécurisé.  
Exposer le port vidéo avec **Tailscale Funnel**.

## Service météo local

Le script `meteo_client.py` s’exécute localement.  
Modifier l’URL du serveur.  
Lancer le script avec Python.

## Étape 7 : Vérification finale

Ouvrir l’URL Render.  
Se connecter avec les identifiants administrateur.  
Vérifier le dashboard.  
Vérifier la connexion MQTT.  
Vérifier le retour caméra.

Le serveur est maintenant pleinement opérationnel.
