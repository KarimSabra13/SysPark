# 🅿️ Smart Parking System (PSM)

> **Un système de stationnement autonome multi-niveaux, piloté par l'intelligence artificielle et l'IoT.**

![Project Status](https://img.shields.io/badge/Status-Functional-brightgreen)
![Tech](https://img.shields.io/badge/Stack-Zephyr%20%7C%20Python%20%7C%20YOLOv8-blue)
![Hardware](https://img.shields.io/badge/Hardware-STM32%20%7C%20BeagleY--AI-orange)

---

## 📖 Présentation

Le **Smart Parking System (PSM)** est une solution complète de gestion de parking automatisé.  
Il combine la robotique (ascenseur à voitures), la vision par ordinateur (lecture de plaques minéralogiques) et le **Cloud Computing** afin d’offrir une expérience utilisateur fluide, de l’entrée à la sortie.

Ce projet a été réalisé dans le cadre du module **N6 – Systèmes Numériques Avancés**.  
Il adresse des problématiques concrètes de **temps réel**, de **sécurité**, de **communication IoT sécurisée** et d’**intelligence artificielle en bordure (Edge AI)**.

---

## 🏗️ Architecture du système

Le système est distribué sur trois entités principales qui communiquent via le protocole **MQTT sécurisé (TLS)**.

```mermaid
graph TD
    User((Utilisateur))

    subgraph "Zone Cloud (Backend)"
        Server[Serveur Flask / Render]
        DB[(PostgreSQL)]
        Stripe[Paiement Stripe]
        Telegram[Bot Telegram]
    end

    subgraph "Zone Bordure (Edge AI)"
        Beagle[BeagleY-AI]
        CamIn(Caméra Entrée)
        CamOut(Caméra Sortie)
        LED[Bandeau LED]
    end

    subgraph "Zone Contrôle (Temps Réel)"
        STM32[STM32F746G-DISCO]
        Motor(Moteur Ascenseur)
        RFID(Lecteur Badge)
        Screen(Écran Tactile)
    end

    User -->|Plaque / Badge| Beagle
    User -->|Tactile / QR| STM32

    Beagle -->|MQTT : Plaques / Vidéo| Server
    STM32 -->|MQTT : États / Badges| Server

    Server -->|MQTT : Commandes| STM32
    Server -->|MQTT : Textes| Beagle

    STM32 -->|SPI| Motor
    Beagle -->|SPI| LED
```

### Cerveau central – Cloud

Hébergé sur **Render**, le serveur Python/Flask gère la logique métier :  
gestion des utilisateurs, tarification, base de données PostgreSQL, paiements sécurisés via **Stripe** et notifications **Telegram**.  
Il orchestre les autorisations d’ouverture et la synchronisation globale du système.

### Contrôleur temps réel – STM32

Basé sur **Zephyr RTOS**, il garantit la sécurité physique et le déterminisme temps réel.  
Il pilote le moteur de l’ascenseur (driver **TMC5160**), gère les capteurs de sécurité, l’interface tactile (**LVGL**) et le lecteur RFID.

### Intelligence visuelle – BeagleY-AI

Passerelle locale d’**Edge AI** exploitant **YOLOv8** et **Tesseract OCR** pour la lecture de plaques en temps réel.  
Elle gère également l’affichage matriciel LED et le streaming vidéo sécurisé vers le Cloud.

---

## ✨ Fonctionnalités clés

### 🚗 Entrée et sortie fluides

Reconnaissance automatique des plaques (ALPR).  
Ouverture automatique si le véhicule est autorisé.  
Accès rapide par badges RFID pour les abonnés.  
Code PIN de secours via écran tactile.

### 🛗 Gestion intelligente de l’ascenseur

Positionnement précis du véhicule.  
Rampes d’accélération et de décélération contrôlées.  
Homing automatique au démarrage.  
Sécurité active en cas de coupure d’alimentation.

### 💳 Paiement et services

QR Code dynamique généré à la sortie.  
Paiement CB sécurisé via Stripe avec validation instantanée.  
Affichage météo locale et informations environnementales.

---

## 📂 Organisation du dépôt

Ce dépôt est un **monorepo** regroupant l’ensemble des sous-systèmes du projet.

| Dossier | Description | Technologies |
| :--- | :--- | :--- |
| `/Zephyr_STM32` | Firmware du microcontrôleur temps réel | C, Zephyr, LVGL |
| `/Backend` | Serveur Web, API, base de données | Python, Flask, Docker |
| `/BeagleY-AI` | Vision par ordinateur, IA, MQTT | Python, YOLOv8, GStreamer |
| `/BMS` | Système de gestion batterie | KiCad, Altium |
| `/Docs` | Documentation technique et rapports | PDF, schémas |

---

## 🚀 Démarrage rapide

Backend  
→ Déployer le serveur Cloud sur Render (README Backend).

STM32  
→ Flasher la carte STM32F746G-DISCO (README embarqué).

BeagleY-AI  
→ Installer les services Edge AI et MQTT (README Edge AI).

---

## 🔧 Prérequis matériels principaux

1x STM32F746G-DISCO  
1x BeagleY-AI  
1x moteur NEMA17 + driver TMC5160  
2x caméras CSI ou USB  
4x modules LED MAX7219  
Connexion Internet Ethernet

---

## 👥 Équipe et contributions

Projet réalisé par l’équipe **PSM – Parking System Masters**.

Architecture système et Zephyr  
→ [Ton Nom]

Backend et Cloud  
→ [Nom Membre 2]

Vision par ordinateur et IA  
→ [Nom Membre 3]

Électronique et BMS  
→ [Nom Membre 4]

---

© 2024 – Projet académique – École d’ingénieurs
