# Documentation Technique Complète et Rapport d'Architecture : Nœud BeagleY-AI (SysPark)

## Table des matières

- [1. Introduction Stratégique et Contextualisation du Projet SysPark](#1-introduction-strategique-et-contextualisation-du-projet-syspark)
- [2. Architecture Matérielle et Spécifications du Nœud BeagleY-AI](#2-architecture-materielle-et-specifications-du-noeud-beagley-ai)
  - [2.1 Analyse du SoC Texas Instruments AM67A](#21-analyse-du-soc-texas-instruments-am67a)
  - [2.2 Topologie des Interfaces et Connectique (Pinout & Bus)](#22-topologie-des-interfaces-et-connectique-pinout-bus)
    - [2.2.1 Le Bus I2C (Inter-Integrated Circuit)](#221-le-bus-i2c-inter-integrated-circuit)
    - [2.2.2 Le Bus SPI (Serial Peripheral Interface)](#222-le-bus-spi-serial-peripheral-interface)
    - [2.2.3 Interfaces d'Acquisition Vidéo (CSI & USB)](#223-interfaces-dacquisition-video-csi-usb)
  - [2.3 Tableau Récapitulatif du Pinout SysPark](#23-tableau-recapitulatif-du-pinout-syspark)
- [3. Configuration Avancée du Système d'Exploitation et du Noyau](#3-configuration-avancee-du-systeme-dexploitation-et-du-noyau)
  - [3.1 Stratégie de l'OS : TI EdgeAI (Debian 12 Bookworm)](#31-strategie-de-los-ti-edgeai-debian-12-bookworm)
  - [3.2 Mécanisme de "Device Tree Overlays"](#32-mecanisme-de-device-tree-overlays)
  - [3.3 Gestion de l'Environnement Python (PEP 668)](#33-gestion-de-lenvironnement-python-pep-668)
- [4. Analyse Approfondie de l'Architecture Logicielle Applicative](#4-analyse-approfondie-de-larchitecture-logicielle-applicative)
  - [4.1 Le Pipeline de Vision Artificielle (beagle_vision_combined.py)](#41-le-pipeline-de-vision-artificielle-beagle_vision_combinedpy)
  - [4.2 La Passerelle de Communication Sécurisée (mqtt_bridge.py)](#42-la-passerelle-de-communication-securisee-mqtt_bridgepy)
  - [4.3 Gestion de l'Interface Utilisateur Locale (bandeau_led.py)](#43-gestion-de-linterface-utilisateur-locale-bandeau_ledpy)
  - [4.4 Contrôle Mécatronique (servo_camera.py)](#44-controle-mecatronique-servo_camerapy)
- [5. Procédure de Déploiement et d'Installation Standardisée](#5-procedure-de-deploiement-et-dinstallation-standardisee)
  - [5.1 Préparation du Support de Stockage et Initialisation](#51-preparation-du-support-de-stockage-et-initialisation)
  - [5.2 Activation des Overlays Matériels](#52-activation-des-overlays-materiels)
  - [5.3 Installation de la Pile Logicielle (Environnement Python)](#53-installation-de-la-pile-logicielle-environnement-python)
  - [5.4 Automatisation et Persistance (Systemd)](#54-automatisation-et-persistance-systemd)
  - [5.5 Configuration de l'Accès Distant Sécurisé (Tailscale)](#55-configuration-de-lacces-distant-securise-tailscale)
- [6. Référentiel des Données et Standards de Communication](#6-referentiel-des-donnees-et-standards-de-communication)
  - [6.1 Plan d'Adressage MQTT (Topic Map)](#61-plan-dadressage-mqtt-topic-map)
  - [6.2 Sécurité Opérationnelle](#62-securite-operationnelle)
- [7. Guide de Maintenance et Dépannage (Troubleshooting)](#7-guide-de-maintenance-et-depannage-troubleshooting)
  - [7.1 Diagnostics Système](#71-diagnostics-systeme)
  - [7.2 Analyse des Logs (Journalisation)](#72-analyse-des-logs-journalisation)
  - [7.3 Matrice de Résolution des Problèmes Courants](#73-matrice-de-resolution-des-problemes-courants)
- [8. Conclusion et Perspectives](#8-conclusion-et-perspectives)
    - [Sources des citations](#sources-des-citations)

## 1. Introduction Stratégique et Contextualisation du Projet SysPark

Dans le paysage actuel de l'Internet des Objets (IoT) industriel, la gestion intelligente des infrastructures urbaines, et plus particulièrement des espaces de stationnement, représente un défi technologique majeur. Le projet **SysPark** s'inscrit dans cette dynamique en proposant une solution de gestion de parking B2B (Business-to-Business) qui dépasse les simples mécanismes de contrôle d'accès traditionnels. L'ambition de SysPark est de fournir une plateforme résiliente, sécurisée et intelligente, capable de traiter des données complexes en périphérie de réseau ("Edge Computing") tout en maintenant une synchronisation fluide avec une infrastructure Cloud centralisée.

L'architecture du système SysPark a été conçue selon un paradigme distribué, segmentant les responsabilités fonctionnelles sur trois nœuds distincts afin d'optimiser la latence, la sécurité et la charge de traitement. Cette segmentation répond à une exigence fondamentale des systèmes cyber-physiques : la séparation entre le contrôle temps réel critique, le traitement analytique lourd et la supervision globale.

Le premier nœud, le **Serveur Cloud**, hébergé sur une infrastructure distante, assure la persistance des données à long terme, la gestion des abonnements utilisateurs, l'analytique historique et la supervision globale via un tableau de bord administratif. Il agit comme le point de vérité unique pour l'état du système à l'échelle macroscopique.1

Le second nœud, le **Hardware Terrain**, construit autour d'un microcontrôleur STM32F746G-DISCO et d'un FPGA Nexys A7, est dédié aux opérations "Hard Real-Time". Il gère les interactions physiques immédiates qui ne tolèrent aucune latence réseau, telles que la détection d'obstacles par capteurs ultrasons, le pilotage des moteurs pas à pas de l'ascenseur via des drivers TMC5160, et la lecture des badges RFID pour l'accès physique. Ce nœud garantit la sécurité opérationnelle des mécanismes lourds.1

Le troisième nœud, et l'objet central de ce rapport technique exhaustif, est la **Passerelle Intelligente (Smart Gateway)**, matérialisée par la plateforme **BeagleY-AI**. Située à l'interface entre le monde physique (capteurs visuels, affichage local) et le monde numérique (Cloud), la BeagleY-AI joue un rôle pivot. Elle ne se contente pas de relayer des informations ; elle les transforme. En intégrant des capacités de vision par ordinateur, de gestion de protocoles IoT et d'interface homme-machine, elle déporte l'intelligence du Cloud vers la bordure du réseau ("Edge"), réduisant ainsi la bande passante nécessaire et permettant une réactivité locale accrue.1

Ce document a pour vocation de servir de référence technique définitive pour l'ingénierie, le déploiement et la maintenance du sous-système BeagleY-AI au sein de l'écosystème SysPark. Il détaille avec une granularité fine les choix architecturaux matériels, la configuration du noyau Linux, l'implémentation des micro-services Python, et les protocoles de sécurité mis en œuvre.

## 2. Architecture Matérielle et Spécifications du Nœud BeagleY-AI

Le choix de la plateforme matérielle pour le nœud de passerelle intelligente est critique. Il doit offrir un équilibre précis entre puissance de calcul (pour les algorithmes de vision), connectivité (pour les périphériques et le réseau) et efficacité énergétique. La BeagleY-AI, basée sur le System-on-Chip (SoC) Texas Instruments AM67A, a été sélectionnée pour ses capacités spécifiques en matière d'accélération IA et de traitement du signal, qui la distinguent des ordinateurs monocartes (SBC) génériques.

### 2.1 Analyse du SoC Texas Instruments AM67A

Au cœur de la BeagleY-AI réside le processeur AM67A, une puce conçue spécifiquement pour les applications de vision et d'IA en périphérie. Contrairement aux architectures homogènes classiques, l'AM67A adopte une approche hétérogène qui est particulièrement pertinente pour le projet SysPark.3

Le traitement généraliste est assuré par un cluster de quatre cœurs **ARM Cortex-A53** cadencés à 1,4 GHz. Ces cœurs 64 bits exécutent le système d'exploitation Linux (Debian), gèrent la pile réseau, l'orchestration des conteneurs ou services Python, et la logique métier de haut niveau. Pour SysPark, c'est sur ces cœurs que tournent les scripts de pontage MQTT et le serveur web Flask.3

Cependant, la véritable force de ce SoC pour notre application réside dans ses co-processeurs spécialisés. Il intègre un processeur de signal numérique (DSP) C7x couplé à un accélérateur de multiplication matricielle (MMA), offrant une puissance de calcul combinée de 4 TOPS (Trillions d'Opérations Par Seconde). Cette architecture permet de décharger les tâches d'inférence de réseaux de neurones (comme YOLOv8 utilisé pour la détection de véhicules) du CPU principal. Cela garantit que le processeur principal reste disponible pour la gestion des communications et des périphériques, évitant ainsi les goulots d'étranglement fréquents sur des plateformes moins spécialisées lors du traitement vidéo.3

De plus, le SoC inclut des cœurs **ARM Cortex-R5F** dédiés au temps réel et au contrôle à faible latence. Bien que la gestion temps réel critique de SysPark soit déportée sur le STM32, la présence de ces cœurs sur la BeagleY-AI offre une évolutivité intéressante pour l'avenir, par exemple pour gérer directement des protocoles de communication industrielle à très haute vitesse sans passer par le noyau Linux.5

### 2.2 Topologie des Interfaces et Connectique (Pinout & Bus)

L'intégration de la BeagleY-AI dans le boîtier physique de la borne SysPark repose sur l'exploitation précise de ses interfaces d'entrées/sorties (GPIO). La carte adopte le standard physique du connecteur 40 broches (compatible mécaniquement avec l'écosystème Raspberry Pi), mais le mappage interne vers le SoC AM67A nécessite une configuration logicielle spécifique via des "Device Trees".6

#### 2.2.1 Le Bus I2C (Inter-Integrated Circuit)

Le bus I2C est crucial pour l'interaction avec les contrôleurs de moteurs et les capteurs environnementaux. Sur la BeagleY-AI, plusieurs bus I2C sont disponibles, mais le bus **I2C1** est le principal canal d'expansion exposé sur le connecteur.9

Ce bus est accessible sur les broches physiques 3 (SDA) et 5 (SCL). Une caractéristique électrique importante à noter pour la conception de la carte porteuse ou du câblage est la présence de résistances de tirage (pull-up) internes de 2,2 kΩ connectées au rail 3,3V. Cette configuration impose que les périphériques connectés soient compatibles avec une logique 3,3V et rend ces broches impropres à une utilisation en tant qu'entrées/sorties numériques simples (GPIO), car l'état par défaut est forcé à l'état haut.9

Dans l'architecture SysPark, ce bus est dédié au pilotage du module **PCA9685**. Ce composant est un contrôleur PWM (Pulse Width Modulation) 16 canaux qui agit comme un démultiplexeur de puissance. La BeagleY-AI envoie des commandes de haut niveau via I2C à l'adresse 0x40, et le PCA9685 génère les signaux PWM précis à 50 Hz nécessaires pour positionner les servomoteurs des caméras. Cette architecture déporte la génération de signal, libérant le SoC des contraintes de timing strictes liées au PWM logiciel.1

#### 2.2.2 Le Bus SPI (Serial Peripheral Interface)

Pour les périphériques nécessitant des transferts de données rapides et synchrones, comme les matrices d'affichage LED, SysPark utilise le bus SPI. La BeagleY-AI expose le bus **SPI0** sur les broches 19, 21, 23, 24 et 26.10

Le mappage précis est le suivant :

**MOSI (Master Out Slave In) - Pin 19 / GPIO 10 :** Canal de données sortant vers les LEDs.

**MISO (Master In Slave Out) - Pin 21 / GPIO 9 :** Canal entrant (peu utilisé pour les drivers LED MAX7219 qui sont en écriture seule, mais câblé par standard).

**SCLK (Serial Clock) - Pin 23 / GPIO 11 :** Horloge de synchronisation.

**CE0 (Chip Enable 0) - Pin 24 / GPIO 8 :** Signal de sélection du périphérique principal.

**CE1 (Chip Enable 1) - Pin 26 / GPIO 7 :** Signal de sélection secondaire.

Le module d'affichage LED de SysPark est constitué de quatre contrôleurs **MAX7219** connectés en cascade (Daisy Chain). Cette configuration permet de piloter une matrice de 32x8 pixels en utilisant une seule ligne de sélection (CE0). Le script Python envoie des trames de données sérialisées via l'interface /dev/spidev0.0, qui sont ensuite décalées à travers les registres des quatre contrôleurs pour former l'image complète. L'utilisation du SPI matériel est impérative ici ; une émulation logicielle (Bit-banging) serait trop lente et consommatrice de CPU pour permettre des animations fluides.1

#### 2.2.3 Interfaces d'Acquisition Vidéo (CSI & USB)

La fonction primaire de la BeagleY-AI étant l'analyse visuelle, les interfaces caméras sont des composants critiques. L'architecture supporte une approche hybride pour maximiser la couverture visuelle.11

La **Caméra Principale (IA)** utilise l'interface **MIPI-CSI (Camera Serial Interface)**. Contrairement à une caméra USB qui envoie des données compressées ou traitées, l'interface CSI offre un lien direct à haut débit entre le capteur d'image (ici un Sony IMX219) et le processeur d'image (ISP) intégré au SoC AM67A. Cela permet de récupérer des images brutes (Raw Bayer) avec une latence minimale, de les traiter matériellement (débruitage, balance des blancs) via l'ISP, puis de les transmettre directement en mémoire pour l'analyse par les accélérateurs IA. Cette chaîne de traitement matérielle est essentielle pour maintenir un framerate élevé lors de la détection de véhicules.13

La **Caméra Secondaire** est connectée via l'un des ports **USB 3.0**. Elle offre une vue complémentaire (par exemple, pour la surveillance globale de la zone ou la lecture de plaque arrière). Bien que la latence soit légèrement supérieure due à l'encapsulation USB, elle offre une flexibilité de placement et de câblage supérieure pour les installations physiques complexes.1

### 2.3 Tableau Récapitulatif du Pinout SysPark

Afin de faciliter le câblage et le débogage, le tableau suivant synthétise l'affectation des broches du header 40-pin de la BeagleY-AI dans le contexte spécifique du projet SysPark. Il est impératif de respecter ce schéma pour garantir la compatibilité avec les scripts de configuration fournis.

| Broche Physique | Nom Système (SoC) | Fonction SysPark | Protocole | Périphérique Connecté | Notes Techniques |
| --- | --- | --- | --- | --- | --- |
| Pin 3 | GPIO 2 | I2C1_SDA | I2C | PCA9685 (Servo Driver) | Pull-up 2.2kΩ intégrée. Adresse 0x40. |
| Pin 5 | GPIO 3 | I2C1_SCL | I2C | PCA9685 (Servo Driver) | Pull-up 2.2kΩ intégrée. |
| Pin 19 | GPIO 10 | SPI0_MOSI | SPI | MAX7219 (Affichage LED) | Données série vers la matrice. |
| Pin 21 | GPIO 9 | SPI0_MISO | SPI | Non connecté (NC) | Le MAX7219 ne renvoie pas de données. |
| Pin 23 | GPIO 11 | SPI0_SCLK | SPI | MAX7219 (Affichage LED) | Horloge de synchronisation. |
| Pin 24 | GPIO 8 | SPI0_CE0 | SPI | MAX7219 (Affichage LED) | Chip Select (Active Low). |
| Pin 22 | GPIO 25 | CSI_I2C | I2C/CSI | Caméra IMX219 | Gestion interne via Overlay CSI. |
| Ports USB | USB Host | USB 3.0 | USB | Webcam Secondaire | Interface video1 (typiquement). |

Ce tableau met en évidence la séparation claire des bus : l'I2C est réservé à l'actionnement mécanique (servos), tandis que le SPI est dédié à l'affichage rapide. Cette ségrégation évite les contentions de bus qui pourraient survenir si tous les périphériques partageaient la même interface.7

## 3. Configuration Avancée du Système d'Exploitation et du Noyau

La fiabilité de la BeagleY-AI repose sur une fondation logicielle solide. Le choix du système d'exploitation et sa configuration bas niveau déterminent la capacité du système à exploiter les accélérateurs matériels et à maintenir une stabilité opérationnelle sur le long terme.

### 3.1 Stratégie de l'OS : TI EdgeAI (Debian 12 Bookworm)

Le projet SysPark standardise son déploiement sur l'image officielle **TI EdgeAI**, basée sur **Debian 12 (Bookworm)**. Ce choix n'est pas anodin et mérite une justification technique approfondie.14

Une distribution Linux générique (comme une Debian stock ou une Ubuntu Server) ne contient pas, par défaut, les modifications complexes du noyau nécessaires pour piloter les composants spécifiques du SoC AM67A. L'image TI EdgeAI intègre ce qu'on appelle le "Board Support Package" (BSP) de Texas Instruments. Ce BSP comprend :

**Noyau Linux optimisé (TI-Linux-Kernel) :** Un fork du noyau Linux principal intégrant les drivers pour la gestion de l'énergie (PMIC), le contrôleur d'interruptions (GIC), et les ponts de communication inter-cœurs.

**Drivers d'Accélération IA (TIDL) :** Les bibliothèques nécessaires pour charger des modèles de Deep Learning sur les cœurs DSP/MMA, permettant une inférence rapide et économe en énergie.

**Sous-système Multimédia :** Des versions optimisées de GStreamer et des drivers V4L2 qui exploitent les encodeurs/décodeurs matériels vidéo, cruciaux pour traiter les flux caméras sans saturer le CPU.16

L'utilisation de Debian 12 garantit également l'accès à un vaste dépôt de paquets logiciels stables et sécurisés (apt), facilitant la maintenance et les mises à jour de sécurité du système de base.17

### 3.2 Mécanisme de "Device Tree Overlays"

Sur les architectures embarquées ARM modernes, la configuration matérielle n'est pas autodétectée comme sur un PC (Plug-and-Play/ACPI). Le noyau doit être informé explicitement de chaque composant matériel présent, de son adresse mémoire et de ses connexions d'interruption via une structure de données appelée "Device Tree".

La BeagleY-AI utilise un système flexible d'Overlays (superpositions) qui permet de modifier ce Device Tree au moment du démarrage (Boot time) sans avoir à recompiler le noyau entier. C'est via ce mécanisme que nous activons les interfaces SPI et CSI nécessaires à SysPark.11

Le fichier de configuration central est /boot/firmware/extlinux/extlinux.conf. Ce fichier instruit le chargeur de démarrage U-Boot sur les fichiers .dtbo (Device Tree Blob Overlay) à charger et à fusionner avec le Device Tree de base de la carte.

Dans le contexte de SysPark, deux overlays sont impératifs :

**k3-am67a-beagley-ai-spidev0.dtbo :** Par défaut, les broches du port SPI0 peuvent être configurées en GPIO ou désactivées. Cet overlay reconfigure le multiplexeur de broches (PinMux) du SoC pour router les signaux internes du contrôleur SPI vers les broches externes du header. Il instancie également le driver spidev du noyau, créant l'interface /dev/spidev0.0 accessible par l'espace utilisateur (notre script Python).18

**k3-am67a-beagley-ai-csi0-imx219.dtbo :** Cet overlay est complexe. Il active le contrôleur CSI-RX du SoC, configure les lignes I2C pour la communication avec le capteur caméra, charge le driver spécifique au capteur IMX219, et configure le pipeline ISP. Sans cet overlay, la caméra n'est tout simplement pas visible par le système vidéo Linux.11

La syntaxe dans extlinux.conf doit être précise. La directive fdtoverlays accepte une liste de chemins absolus séparés par des espaces. Une erreur dans ce fichier peut empêcher le système de démarrer correctement ou rendre les périphériques invisibles.20

### 3.3 Gestion de l'Environnement Python (PEP 668)

L'administration des dépendances Python sur les systèmes Linux modernes a évolué pour garantir la stabilité du système. Debian 12 applique la norme **PEP 668**, qui marque l'environnement Python système comme "géré de l'extérieur". Concrètement, cela signifie que l'exécution de sudo pip install X est bloquée pour éviter que l'installation de bibliothèques Python tierces ne vienne écraser ou entrer en conflit avec les bibliothèques gérées par le gestionnaire de paquets du système (apt).

Pour SysPark, la solution préconisée et mise en œuvre est l'utilisation systématique d'environnements virtuels (venv). Un environnement virtuel crée un répertoire isolé contenant sa propre copie de l'interpréteur Python et son propre dossier de bibliothèques. Cela permet d'installer les versions spécifiques de ultralytics, paho-mqtt ou flask requises par l'application sans risquer de perturber les outils système qui dépendent de Python.1

L'environnement virtuel pour SysPark est standardisé dans le répertoire /opt/edgeai-gst-apps/venv. Tous les services système (Systemd) sont configurés pour utiliser explicitement l'interpréteur Python situé dans ce dossier (/opt/edgeai-gst-apps/venv/bin/python3), garantissant que l'application s'exécute toujours avec les bonnes versions de dépendances, indépendamment des mises à jour du système d'exploitation hôte.1

## 4. Analyse Approfondie de l'Architecture Logicielle Applicative

L'application SysPark sur la BeagleY-AI n'est pas un bloc monolithique, mais une collection de micro-services interconnectés. Cette architecture modulaire favorise la résilience : une défaillance dans le module d'affichage LED n'entraîne pas l'arrêt de la détection vidéo ou de la communication réseau. Chaque service est un script Python indépendant, supervisé par le démon systemd.

### 4.1 Le Pipeline de Vision Artificielle (beagle_vision_combined.py)

Ce module est le composant le plus sophistiqué du système, exploitant la puissance de calcul de l'AM67A. Son fonctionnement peut être décomposé en plusieurs étapes de traitement séquentiel.1

**1. Acquisition et Prétraitement :** Le script initialise une capture vidéo via OpenCV (cv2.VideoCapture). Bien que l'interface soit de haut niveau, elle s'appuie en arrière-plan sur les drivers V4L2 configurés par les overlays. Il est impératif d'utiliser la version opencv-python-headless des bibliothèques. Les versions standards d'OpenCV incluent des dépendances vers des bibliothèques d'interface graphique (Qt, GTK) qui sont inutiles sur un système embarqué sans écran et peuvent causer des conflits ou des erreurs d'initialisation dans un environnement serveur.1

**2. Inférence Neuronale (YOLOv8) :**

Le cœur de l'analyse repose sur le modèle **YOLOv8** (You Only Look Once), état de l'art actuel en détection d'objets. Le script charge le modèle via la bibliothèque ultralytics. Il tente prioritairement de charger un modèle personnalisé best.pt (raffiné spécifiquement sur des images de véhicules dans des parkings), et bascule sur le modèle générique yolov8n.pt (nano) en cas d'absence. Le modèle "nano" est privilégié pour sa légèreté, permettant une inférence rapide sur le CPU/DSP sans latence excessive. Le modèle détecte la présence de véhicules et localise la zone probable de la plaque d'immatriculation.

**3. Reconnaissance Optique de Caractères (OCR) :**

Une fois la plaque localisée (Bounding Box), cette région de l'image est extraite (croppée) et passée à **Tesseract OCR** via le wrapper pytesseract. Tesseract analyse les motifs de pixels pour extraire le texte alphanumérique. Cette étape est critique et sensible aux conditions d'éclairage. Le texte brut extrait subit ensuite un post-traitement par expressions régulières (Regex) pour filtrer le bruit et valider que la chaîne correspond au format d'une plaque d'immatriculation (ex: AA-123-BB en France).

**4. Diffusion et Streaming :**

Le script remplit une double fonction. En plus de l'analyse, il agit comme un serveur de streaming vidéo MJPEG léger via **Flask**. Il expose un endpoint HTTP sur le port 8000 qui diffuse le flux vidéo en temps réel avec les annotations de détection (cadres autour des véhicules). Cela permet aux opérateurs de visualiser ce que "voit" l'IA à distance pour le débogage ou la vérification, sans nécessiter de matériel d'affichage local.

### 4.2 La Passerelle de Communication Sécurisée (mqtt_bridge.py)

Dans un système distribué, la gestion des flux de données est aussi importante que leur traitement. Le script mqtt_bridge.py assure l'intégrité des échanges entre le site local et le Cloud.1

**Stratégie de Double Connexion :**

Le script instancie deux clients MQTT distincts. Le **client local** se connecte au broker interne (sur localhost:1883) pour échanger avec les autres processus de la carte (vision, affichage). Le **client Cloud** se connecte au broker distant HiveMQ (sur broker.hivemq.com:8883). Cette séparation est fondamentale : elle permet au système local de continuer à fonctionner de manière autonome (ouvrir la barrière, afficher les places) même en cas de coupure Internet.

**Sécurité et Chiffrement (TLS) :** La connexion vers le Cloud est impérativement sécurisée par **TLS (Transport Layer Security)**. Le script utilise client.tls_set() pour activer le chiffrement SSL/TLS. Cela garantit que les données sensibles (numéros de plaques, commandes d'ouverture de barrière) ne peuvent pas être interceptées ou falsifiées lors de leur transit sur l'Internet public. C'est une exigence incontournable pour un déploiement B2B professionnel.1

**Listes de Contrôle d'Accès (ACL) et Filtrage :**

Pour prévenir les boucles de messages (un message répercuté indéfiniment entre le local et le cloud) et sécuriser le système contre des commandes malveillantes, le pont implémente une logique de filtrage stricte par listes blanches.

ALLOW_CLOUD_TO_LOCAL : Définit explicitement quels topics sont autorisés à descendre du Cloud vers le site (ex: commandes d'affichage, mises à jour de configuration). Tout message sur un topic non listé est ignoré.

ALLOW_LOCAL_TO_CLOUD : Définit quelles données locales (télémétrie, détections) peuvent remonter.
Cette logique transforme le pont en un pare-feu applicatif MQTT intelligent.

### 4.3 Gestion de l'Interface Utilisateur Locale (bandeau_led.py)

L'expérience utilisateur sur le terrain dépend de la clarté des informations affichées. Le module bandeau_led.py gère cette interaction.1

Le script s'abonne au topic MQTT parking/display/text. Dès réception d'un message, il le traite pour l'affichage sur la matrice LED. La complexité réside dans la gestion bas niveau du matériel. Contrairement à un écran HDMI géré par le GPU, ici le script doit générer la représentation binaire de chaque caractère (bitmap) et l'envoyer pixel par pixel aux contrôleurs MAX7219 via le bus SPI.

Le script intègre également une logique autonome d'économie d'énergie et de confort visuel. Il peut ajuster l'intensité lumineuse des LEDs ou passer en mode veille si aucune activité n'est détectée, contribuant à la longévité du matériel et à la réduction de la pollution lumineuse nocturne.

### 4.4 Contrôle Mécatronique (servo_camera.py)

Ce module illustre l'interaction avec le bus I2C. Il traduit des commandes de haut niveau reçues via MQTT (parking/camera/cmd avec payload JSON {angle_pan, angle_tilt}) en signaux électriques concrets.1

Le script utilise la bibliothèque smbus2 pour envoyer des registres de configuration au contrôleur PCA9685. Il calcule les valeurs de "ON time" et "OFF time" pour le signal PWM afin d'obtenir la largeur d'impulsion précise (généralement entre 1ms et 2ms) qui correspond à l'angle désiré du servomoteur. Cette abstraction permet au système central d'envoyer une commande simple "Regarde à 90 degrés" sans avoir à se soucier de la fréquence PWM ou de l'adresse I2C du composant.

## 5. Procédure de Déploiement et d'Installation Standardisée

Cette section détaille la procédure technique pour transformer une carte BeagleY-AI vierge en un nœud opérationnel SysPark. Chaque étape est justifiée par les contraintes architecturales exposées précédemment.

### 5.1 Préparation du Support de Stockage et Initialisation

**Sélection et Flashage de l'OS :** Télécharger l'image système recommandée : **BeagleBoard.org Debian Bookworm Xfce** (ou la variante Minimal pour la production) depuis le site officiel BeagleBoard.org. Utiliser un outil comme BalenaEtcher pour écrire cette image sur une carte microSD de qualité industrielle (Classe 10 / A1 minimum, 32 Go recommandés pour stocker les logs et le tampon vidéo).14

Configuration Initiale (sysconf.txt) :
Avant d'insérer la carte dans la BeagleY-AI, une étape de configuration "Headless" (sans écran) est possible et recommandée. Sur la partition de boot de la carte SD (lisible depuis Windows/Mac), éditer le fichier sysconf.txt.

Décommenter et définir user_name et user_password.

Configurer les identifiants Wi-Fi si une connexion Ethernet n'est pas disponible immédiatement. Cette étape permet à la carte de se connecter au réseau dès le premier démarrage, facilitant l'accès SSH initial.15

Premier Démarrage et Mise à Jour :
Insérer la carte SD, connecter l'alimentation USB-C (5V/3A minimum requis). Attendre l'initialisation (les LEDs de la carte indiquent l'activité). Se connecter via SSH (ssh utilisateur@beagley-ai.local).
Exécuter immédiatement une mise à jour complète pour garantir que le noyau et les firmwares sont aux dernières versions supportées :

```bash
sudo apt update && sudo apt full-upgrade -y
```

### 5.2 Activation des Overlays Matériels

C'est l'étape la plus critique pour la fonctionnalité matérielle. Sans cela, les scripts Python échoueront avec des erreurs d'E/S.11

Ouvrir le fichier de configuration du chargeur de démarrage :

```bash
sudo nano /boot/firmware/extlinux/extlinux.conf
```

Localiser la section correspondant au label de démarrage par défaut (label microSD (default)).

Ajouter ou modifier la ligne fdtoverlays. Il est impératif d'inclure les chemins vers les overlays SPI et CSI. La ligne doit ressembler exactement à ceci (en une seule ligne) :
fdtoverlays /overlays/k3-am67a-beagley-ai-spidev0.dtbo /overlays/k3-am67a-beagley-ai-csi0-imx219.dtbo
Note technique : L'ordre des overlays n'a généralement pas d'importance, mais il est crucial que les noms de fichiers soient exacts. Une faute de frappe ici empêchera le chargement du driver correspondant.

Sauvegarder et redémarrer le système (sudo reboot).

Au redémarrage, valider l'activation :

ls /dev/spi* doit retourner /dev/spidev0.0.

ls /dev/video* doit lister plusieurs périphériques vidéo (le driver CSI crée souvent plusieurs nœuds pour les métadonnées et le flux principal).

Exécuter sudo beagle-camera-setup pour confirmer que le capteur IMX219 est bien identifié sur le bus CSI.11

### 5.3 Installation de la Pile Logicielle (Environnement Python)

Dépendances Système :
Installer les bibliothèques C nécessaires à la compilation des modules Python et au support matériel :

```bash
sudo apt install python3-venv python3-pip tesseract-ocr libgstreamer1.0-dev libopenblas-dev libhdf5-dev i2c-tools
```

Création de l'Environnement Virtuel :
Nous créons un répertoire dédié pour l'application afin de l'isoler du reste du système.

```bash
sudo mkdir -p /opt/edgeai-gst-apps
sudo chown $USER:$USER /opt/edgeai-gst-apps
cd /opt/edgeai-gst-apps
python3 -m venv venv
```

L'activation de l'environnement (source venv/bin/activate) modifie temporairement les variables d'environnement PATH pour que la commande python pointe vers notre version isolée.

Installation des Bibliothèques Python :
Dans l'environnement activé, installer les paquets. L'option --upgrade pip est souvent nécessaire pour éviter des erreurs de compilation de roues (wheels) sur l'architecture ARM64.

```bash
pip install --upgrade pip
pip install flask ultralytics pytesseract paho-mqtt smbus2 amqtt requests pyserial opencv-python-headless
```

Rappel : L'utilisation de opencv-python-headless est impérative pour la stabilité du serveur.

### 5.4 Automatisation et Persistance (Systemd)

Pour transformer les scripts en services d'arrière-plan robustes (Démons), nous utilisons le système d'init systemd. Cela garantit que l'application démarre automatiquement au boot et redémarre en cas de crash intempestif.

Exemple de fichier d'unité pour le pont MQTT (/etc/systemd/system/mqtt_bridge.service) :

```ini
[Unit]
Description=SysPark MQTT Bridge Service
After=network.target
# Attendre que le réseau soit prêt avant de lancer le pont


Type=simple
User=debian
WorkingDirectory=/opt/edgeai-gst-apps
# Appel direct de l'interpréteur Python de l'environnement virtuel
ExecStart=/opt/edgeai-gst-apps/venv/bin/python3 /opt/edgeai-gst-apps/mqtt_bridge.py
# Politique de redémarrage : toujours redémarrer, même si le code de sortie est 0 (arrêt propre)
Restart=always
RestartSec=5
# Temporisation de 5s pour éviter de saturer le CPU en cas de boucle de crash rapide

[Install]
WantedBy=multi-user.target
```

Il faut créer des fichiers similaires pour simple_broker.service, beagle_vision.service et bandeau_led.service. Une fois créés, il faut recharger le démon systemd et activer les services :

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now simple_broker.service
sudo systemctl enable --now mqtt_bridge.service
sudo systemctl enable --now bandeau_led.service
sudo systemctl enable --now beagle_vision.service
```

### 5.5 Configuration de l'Accès Distant Sécurisé (Tailscale)

Pour la télémaintenance, SysPark n'utilise pas de redirection de port (Port Forwarding) sur le routeur local, ce qui poserait des problèmes de sécurité et de gestion d'IP dynamique. Nous utilisons **Tailscale**, un VPN maillé "Zero Config" basé sur le protocole WireGuard.21

Installer Tailscale : curl -fsSL <https://tailscale.com/install.sh> | sh

Authentifier la machine : sudo tailscale up. Copier l'URL fournie pour lier la BeagleY-AI à votre réseau privé (Tailnet).

Fonctionnalité "Funnel" : Pour exposer le flux vidéo de débogage (port 8000) de manière sécurisée et temporaire à des développeurs externes sans leur donner accès à tout le VPN :

```bash
sudo tailscale funnel 8000
```

Cela crée une URL publique HTTPS (ex: https://beagley-ai.tailnet-name.ts.net) qui redirige vers le port local 8000, sécurisée par les certificats TLS gérés automatiquement par Tailscale.1

## 6. Référentiel des Données et Standards de Communication

La standardisation des échanges de données est la clé de voûte de l'interopérabilité dans SysPark. Nous utilisons MQTT v3.1.1/5.0 comme colonne vertébrale.

### 6.1 Plan d'Adressage MQTT (Topic Map)

L'arbre des topics est conçu pour être hiérarchique, logique et extensible. La racine parking/ isole l'application des autres systèmes potentiels sur le même broker.

| Topic | Direction (Vue du Bridge) | QoS | Description Fonctionnelle | Exemple de Payload (JSON) |
| --- | --- | --- | --- | --- |
| parking/sensor_gate/present | Local -> Cloud | 1 | Détection véhicule à la barrière. QoS 1 garantit la livraison au moins une fois. | {"state": true, "ts": 170652...} |
| parking/sensor_gate/heartbeat | Local -> Cloud | 0 | "Battement de cœur" périodique (toutes les 60s) pour monitoring de disponibilité. QoS 0 suffit. | {"status": "ok", "uptime": 3600} |
| parking/sensor_gate/error | Local -> Cloud | 2 | Alerte critique (défaillance capteur). QoS 2 garantit la livraison unique exacte. | {"code": "ERR_ULTRASONIC_TIMEOUT"} |
| parking/display/text | Cloud -> Local | 1 | Commande d'affichage pour les conducteurs. | "LIBRE: 05" ou "BIENVENUE" |
| parking/camera/cmd | Cloud -> Local | 0 | Commande de positionnement temps réel des caméras (Pan/Tilt). | {"pan": 90, "tilt": 45} |
| parking/config/pin | Cloud -> Local | 2 | Reconfiguration dynamique des GPIOs (ex: changer une pin d'entrée en sortie). | {"pin": 12, "mode": "INPUT", "pull": "UP"} |
| parking/meteo | Local -> Cloud | 0 | Données contextuelles (OpenWeatherMap). | {"temp": 12.5, "condition": "Pluie"} |

### 6.2 Sécurité Opérationnelle

Outre le chiffrement TLS vers le Cloud, la sécurité opérationnelle est renforcée par :

**Isolation du Broker Local :** Le broker amqtt interne n'écoute que sur l'interface locale ou le réseau privé, jamais sur l'interface publique WAN.

**Watchdogs Logiciels :** Les scripts critiques (sensor_gate sur l'ESP32 et mqtt_bridge sur la BeagleY-AI) implémentent des mécanismes de "chien de garde". Si la connexion au broker est perdue, ils tentent une reconnexion automatique. Si le processus se fige, systemd le redémarre.

## 7. Guide de Maintenance et Dépannage (Troubleshooting)

Pour assurer une haute disponibilité, les opérateurs doivent maîtriser les outils de diagnostic de la BeagleY-AI.

### 7.1 Diagnostics Système

La première étape de tout dépannage est de vérifier l'état des services.

```bash
sudo systemctl status simple_broker mqtt_bridge beagle_vision bandeau_led
```

Un service en état failed ou activating (en boucle) indique un problème.

### 7.2 Analyse des Logs (Journalisation)

Systemd centralise les logs (stdout/stderr) de tous les services dans journalctl. C'est la source d'information primaire.

Suivre les logs Vision en temps réel :

```bash
journalctl -u beagle_vision -f
```

Rechercher des erreurs comme "Camera not found" (problème overlay/matériel) ou "Model load failed" (fichier .pt manquant).

Déboguer la connectivité Cloud :

```bash
journalctl -u mqtt_bridge -f
```

Rechercher les codes d'erreur TLS (certificat invalide) ou les timeouts de connexion (pare-feu réseau).

### 7.3 Matrice de Résolution des Problèmes Courants

| Symptôme | Cause Technique Probable | Action Corrective |
| --- | --- | --- |
| Écran LED éteint | Overlay SPI non chargé ou défaut d'alimentation 5V. | 1. Vérifier ls /dev/spidev0.0. 2. Vérifier extlinux.conf. 3. Mesurer la tension 5V sur le connecteur MAX7219. |
| Erreur "Resource Busy" (Caméra) | Conflit d'accès au fichier /dev/video0. | Un autre processus (ex: un serveur web de test) utilise la caméra. Arrêter tous les services utilisant la vidéo : sudo systemctl stop beagle_vision. |
| Latence MQTT élevée | Mauvaise qualité du lien Wi-Fi ou saturation CPU. | 1. Vérifier le signal Wi-Fi avec iwconfig. 2. Vérifier la charge CPU avec htop (si >95%, le modèle YOLO est peut-être trop lourd, passer au modèle nano). |
| Pas de remontée Cloud | Filtrage ACL trop strict ou erreur d'authentification HiveMQ. | 1. Vérifier la liste ALLOW_LOCAL_TO_CLOUD dans mqtt_bridge.py. 2. Vérifier les identifiants dans le script. |

## 8. Conclusion et Perspectives

La BeagleY-AI se révèle être la pierre angulaire de l'architecture SysPark. Par sa conception matérielle orientée IA et sa flexibilité logicielle (Linux/Python), elle permet de déployer une intelligence sophistiquée au plus près de l'action. Ce rapport a démontré comment configurer, sécuriser et exploiter cette plateforme pour répondre aux exigences d'un système de stationnement moderne : réactivité, robustesse et connectivité.

L'architecture mise en place est conçue pour être évolutive. Les capacités inexploitées du SoC (cœurs R5F, DSP additionnels) offrent des perspectives d'amélioration futures, telles que l'analyse du comportement des véhicules (détection d'anomalies de trajectoire) ou l'intégration de protocoles de communication véhicule-infrastructure (V2X), sans nécessiter de refonte matérielle majeure.

*Ce rapport technique a été élaboré sur la base des spécifications du projet SysPark, de la documentation Texas Instruments et des standards de l'industrie pour l'IoT sécurisé.*

#### Sources des citations

Readme_GLOBAL.md

HiveMQ Cloud – Fully-Managed MQTT Platform on the Cloud | Free ..., consulté le janvier 24, 2026,

BeagleY-AI - Farnell, consulté le janvier 24, 2026,

The BeagleY-AI Handbook (Extract) by Elektor - Issuu, consulté le janvier 24, 2026,

BeagleY-AI - Zephyr Documentation, consulté le janvier 24, 2026,

Design and Specifications - BeagleBoard Documentation, consulté le janvier 24, 2026,

BeagleY-AI GPIO Pinout, consulté le janvier 24, 2026,

Using GPIO - BeagleBoard Documentation, consulté le janvier 24, 2026,

I2C at BeagleY-AI GPIO Pinout, consulté le janvier 24, 2026,

SPI at BeagleY-AI GPIO Pinout, consulté le janvier 24, 2026,

Using IMX219 CSI Cameras - BeagleBoard Documentation, consulté le janvier 24, 2026,

4 lane CSI supported cameras on BeagleY AI - General Discussion - BeagleBoard Forum, consulté le janvier 24, 2026,

gateway240/beagley-ai-demos - GitHub, consulté le janvier 24, 2026,

Debian - BeagleBoard, consulté le janvier 24, 2026,

Beagley-AI - Olof Astrand - Medium, consulté le janvier 24, 2026,

GStreamer usage with BeagleY-AI - General Discussion - BeagleBoard Forum, consulté le janvier 24, 2026,

Quick Start Guide for BeagleY-AI Table of Contents, consulté le janvier 24, 2026,

BeagleY-AI: spi - General Discussion - BeagleBoard Forum, consulté le janvier 24, 2026,

CSI IMX219 camera to work with BeagleY-AI - General Discussion - BeagleBoard Forum, consulté le janvier 24, 2026,

BeagleY-AI adding overlays when using NVMe hangs boot - BeagleBoard Forum, consulté le janvier 24, 2026,

Install Tailscale on Linux, consulté le janvier 24, 2026,

Few Linux Tailscale setup tips - Reddit, consulté le janvier 24, 2026,
