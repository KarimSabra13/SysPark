# SysPark — Sous-système STM32 (STM32F746G-DISCO + Zephyr RTOS)

## 1. Rôle du nœud STM32 dans l’architecture SysPark

Le sous-système STM32 est le nœud terrain du projet SysPark. Il assure le contrôle temps réel des actionneurs et des capteurs au niveau de la barrière (moteur pas-à-pas, fin de course, RFID, affichage local), puis synchronise l’état et les commandes avec la passerelle BeagleY‑AI via MQTT sur Ethernet.

Dans l’architecture globale, la BeagleY‑AI gère les traitements lourds (vision, broker local, pont cloud) tandis que le STM32 exécute les tâches déterministes et sûres, au plus près du matériel.

## 2. Pourquoi Zephyr RTOS

Zephyr est retenu pour trois raisons principales.

La première est le comportement temps réel. Le pilotage STEP/DIR d’un driver moteur, la lecture d’un fin de course, ou la gestion d’une interface utilisateur requièrent une latence maîtrisée et répétable, ce que permet un RTOS.

La seconde est l’intégration réseau industrielle. La pile réseau Zephyr (sockets, TCP/IP, MQTT) est conçue pour tourner sur microcontrôleur avec des compromis explicites en RAM, ce qui simplifie le déploiement d’un client MQTT robuste au niveau du nœud terrain.

La troisième est la standardisation. Zephyr fournit un modèle de configuration cohérent via Kconfig (prj.conf), une description matériel portable via Devicetree (overlay), et un outillage unifié via west, ce qui rend le projet reproductible sur poste de dev et sur CI.

## 3. Pourquoi la STM32F746G-DISCO

La STM32F746G‑DISCO est adaptée à SysPark car elle combine un cœur Cortex‑M7 performant avec une connectivité Ethernet et un support Zephyr mature pour cette carte.

Ce choix réduit le temps d’intégration, car la carte propose un ST‑LINK intégré pour flasher et déboguer, et elle expose de nombreux GPIO sur headers, ce qui facilite l’interface avec un driver moteur, un lecteur RFID, un écran OLED et des capteurs.

## 4. Matériel requis

| Composant | Description | Interface |
|---|---|---|
| STM32F746G-DISCO | Carte de développement principale (Cortex‑M7) | — |
| Driver moteur | Module type TMC5160 (ou compatible STEP/DIR + SPI de configuration) | GPIO + SPI |
| Moteur pas-à-pas | NEMA 17 ou NEMA 23 | — |
| Lecteur RFID | RC522 | SPI2 |
| Écran OLED | SSD1306/SH1106 128×64 | SPI5 |
| Capteur fin de course | Switch mécanique | GPIO |
| Carte microSD | Stockage FAT | SDMMC1 |

## 5. Câblage et pinout

Le projet utilise les connecteurs type Arduino de la Discovery, plus des broches d’extension. La STM32F746G‑DISCO a une ambiguïté historique de documentation sur certaines correspondances Arduino (notamment D10 et D5). Ce projet verrouille les affectations via l’overlay Devicetree pour lever toute ambiguïté en production.

### 5.1 Moteur et capteur fin de course

| Signal SysPark | Broche STM32 | Logique | Remarque |
|---|---:|---|---|
| Motor Enable | PI0 | Active LOW | Autorisation driver |
| Motor Step | PI3 | Active HIGH | Impulsions STEP |
| Motor Dir | PH6 | Active HIGH | Direction |
| Limit Switch | PG7 | Active HIGH + pull‑down | Sécurité fin de course |

### 5.2 Bus SPI2 partagé : RC522 et TMC5160

Le bus SPI2 est partagé entre le lecteur RFID et le driver moteur. La sélection se fait par deux Chip Selects.

| Fonction | SCK | MISO | MOSI | CS |
|---|---|---|---|---|
| SPI2 (commun) | PI1 | PB14 | PB15 | — |
| RFID RC522 | — | — | — | PA8 (CS index 0) |
| Driver TMC5160 | — | — | — | PA15 (CS index 1) |

Dans Zephyr, l’index du CS sélectionné est déterminé par la valeur `reg` dans le nœud enfant SPI, et correspond à l’index dans `cs-gpios`. Avec `cs-gpios = <PA8>, <PA15>`, alors `reg = <0>` utilise PA8 et `reg = <1>` utilise PA15.

### 5.3 Bus SPI5 : écran OLED

| Signal | Broche STM32 | Remarque |
|---|---:|---|
| SCK | PF7 | SPI5 |
| MOSI | PF9 | SPI5 |
| CS | Défini applicativement | Peut être ajouté en GPIO dédié si nécessaire |

## 6. Organisation du projet dans Zephyr

### 6.1 Pourquoi le dossier `samples/net/mqtt_publisher` est imposé

Le projet SysPark STM32 est construit comme une adaptation directe de l’exemple Zephyr `mqtt_publisher`. Cette contrainte n’est pas “cosmétique” : ce sample fournit une structure CMake/Kconfig déjà câblée pour la pile MQTT (dépendances réseau, options de build, intégration du shell réseau, etc.). En pratique, placer les fichiers ailleurs sans reconfigurer l’app Zephyr conduit facilement à des erreurs de configuration ou de liens.

Emplacement cible (exemple macOS, conforme à votre workspace) :

```text
/Users/Dajid/zephyrproject/zephyr/samples/net/mqtt_publisher
```

### 6.2 Structure attendue

L’application doit contenir au minimum.

```text
samples/net/mqtt_publisher/
  CMakeLists.txt
  prj.conf
  boards/
    stm32f746g_disco.overlay
  src/
    (code applicatif SysPark)
```

Le dossier `src/` n’est pas laissé “libre” dans SysPark : votre implémentation actuelle contient un découpage précis, aligné sur les sous‑systèmes matériels et sur les échanges MQTT.

Arborescence réelle (à placer dans `samples/net/mqtt_publisher/src/`).

```text
src/
  ascenseur_controle.c
  config.h
  lcd_display.c
  main.c
  main_rfid.c
  mqtt_thread.c
  oled_thread.c
  QR_code.c
  role_config.h
```

### 6.3 Description détaillée des fichiers `src/`

| Fichier | Rôle dans SysPark | Interfaces et dépendances notables |
|---|---|---|
| `main.c` | Point d’entrée applicatif et orchestration. Initialise la carte SD, charge les fichiers persistants (`pin.txt`, `exit_pin.txt`, `users.txt`), instancie l’UI LVGL (écran TFT), et lance les threads applicatifs. Contient la logique d’IHM (clavier, champs, état), la logique admin (badge “admin”), et le scénario de paiement côté sortie. | Déclare `uid_msgq` (UID RFID), `payment_msgq` (infos de paiement), `payment_success_sem` (validation serveur), et `sd_lock` (mutex SD). Démarre le thread MQTT (`mqtt_thread`) et le thread `uid_handler_thread()`. En mode `BOARD_ROLE_ENTRY`, démarre aussi `ascenseur_thread()`. |
| `role_config.h` | Sélection du rôle compile‑time de la carte. Deux modes : `BOARD_ROLE_ENTRY` (entrée) et `BOARD_ROLE_EXIT` (sortie). Le rôle conditionne les fonctionnalités actives et évite de maintenir deux firmwares séparés. | Inclus par `main.c` et `mqtt_thread.c`. En mode sortie, le thread UID handler est explicitement désactivé (blocage volontaire), et le scénario de paiement est activé. En mode entrée, l’ascenseur, le LCD I2C et la logique “barrière” sont actifs. |
| `mqtt_thread.c` | Client MQTT Zephyr. Gère la connexion TCP, la boucle d’événements, les souscriptions, et le routage des messages vers les modules locaux. À la connexion, publie la liste ACL locale et envoie une demande de synchronisation au serveur. | Basé sur l’infrastructure du sample Zephyr `mqtt_publisher` (helpers réseau et configuration). Souscriptions : `parking/meteo`, `parking/display/text`, `parking/config/pin`, `parking/config/exit_pin`, `parking/payment/req`, `parking/payment/success`, `parking/ascenseur/cmd`, `parking/ascenseur/get`, `parking/acl/add`, `parking/acl/del`, `parking/acl/full`, `parking/acl/enroll`, `parking/acl/get`. Publications : `parking/barriere` (UID, QoS1), `parking/ascenseur/state` (état, retain), `parking/acl/list` (liste ACL, retain), `parking/acl/event` (accusés SD), `parking/sync/req` (QoS1). Parsing JSON via `cJSON`. Utilise un secret applicatif `MQTT_SECRET` inséré dans les messages ACL. |
| `config.h` | Configuration issue et adaptée du sample `mqtt_publisher`. Centralise les paramètres MQTT (adresse broker, port, identifiants) et certains choix du sample (buffers, options réseau). | Étroitement lié au sample, ce qui justifie l’implantation du projet dans `samples/net/mqtt_publisher`. Le broker et l’IP sont pilotés via `prj.conf` (net config), puis consommés par les utilitaires du sample. |
| `main_rfid.c` | Driver applicatif RC522 (SPI) et thread de lecture RFID. Réalise l’initialisation RC522, l’anti‑collision, l’extraction UID, puis envoie l’UID sous forme hexadécimale dans `uid_msgq`. | Utilise le nœud Devicetree `rc522` sous `SPI2` et `SPI_DT_SPEC_GET`. Dépend de `uid_msgq` (déclarée dans `main.c`). Le câblage CS dépend du couple `cs-gpios` (sur le contrôleur SPI) et `reg` (sur le périphérique SPI) dans l’overlay. Dans votre overlay, le RC522 est `reg=<0>` et utilise donc l’index CS0. |
| `ascenseur_controle.c` | Contrôle moteur pas‑à‑pas pour le mécanisme d’ascenseur. Gère STEP/DIR/ENABLE, les rampes (accélération/décélération), le fin de course (homing), et les demandes d’étage (boutons et commandes MQTT). | Actif en mode `BOARD_ROLE_ENTRY`. Expose `ascenseur_request_floor()` et des fonctions d’état lues par l’OLED. Utilise `motor-enable`, `motor-step`, `motor-dir` et `limit-switch` (Devicetree). Configure les boutons en interruptions GPIO pour demander RDC, étage 1, étage 2. |
| `lcd_display.c` | Gestion d’un LCD I2C 20×4 (adresse 0x27). Affiche des pages d’informations (météo, places disponibles), et expose des fonctions d’update depuis MQTT. | Actif en mode `BOARD_ROLE_ENTRY`. Consomme les payloads MQTT routés par `mqtt_thread.c` via `lcd_update_from_mqtt()` (JSON météo) et `lcd_update_places()` (texte “places”). |
| `oled_thread.c` | Driver applicatif OLED SH1106 (SPI) et thread d’affichage “statut ascenseur”. Affiche l’étage courant, la cible, la direction et l’état de homing. | Lit l’état via `ascenseur_get_current_floor()`, `ascenseur_get_target_floor()`, `ascenseur_is_going_up()`, `ascenseur_is_homing()`. Utilise `SPI5` et des GPIO dédiés (CS/DC/RST) gérés dans le code (le CS est piloté applicativement). |
| `QR_code.c` | Ressource graphique LVGL (image) destinée à l’UI de paiement. Le contenu est un tableau de pixels généré (format LVGL) et déclaré via `LV_IMAGE_DECLARE(QR_code)` dans `main.c`. | Utilisé en mode `BOARD_ROLE_EXIT` pour afficher un QR de paiement (ou une image placeholder). Le fichier peut être régénéré à partir d’une image source si le QR doit changer. |

### 6.4 Architecture d’exécution (threads, IPC, synchronisation)

L’application s’appuie sur plusieurs threads Zephyr afin d’isoler les contraintes temps réel (moteur), les I/O (RFID, écrans), et le réseau (MQTT). Le tableau ci‑dessous reflète les déclarations présentes dans votre code.

| Thread | Déclaration | Priorité | Rôle |
|---|---|---:|---|
| MQTT | `k_thread_create()` depuis `main.c` | 1 | Connexion au broker, souscriptions SysPark, publication d’événements, routage vers modules locaux. |
| UID handler | `K_THREAD_DEFINE(uid_handler_tid, 4096, …)` dans `main.c` | 3 | Consomme `uid_msgq`, gère le mode admin, l’inscription locale et l’accès, puis publie l’UID via `parking/barriere`. Désactivé en mode sortie. |
| RFID | `K_THREAD_DEFINE(rfid_tid, 2048, …)` dans `main_rfid.c` | 5 | Lecture RC522, extraction UID, envoi dans `uid_msgq`. |
| LCD I2C | `K_THREAD_DEFINE(lcd_display_tid, …)` dans `lcd_display.c` | 7 | Rafraîchissement LCD 20×4, pages météo/places, transitions. |
| Ascenseur | `K_THREAD_DEFINE(ascenseur_tid, 4096, …)` dans `main.c` | 8 | Pilotage moteur, homing fin de course, demandes d’étage, publication d’état. Uniquement en mode entrée. |
| OLED | `K_THREAD_DEFINE(oled_thread_id, 2048, …)` dans `oled_thread.c` | 12 | Affichage du statut ascenseur (étage, direction, homing). |

Les mécanismes de synchronisation utilisés sont centralisés dans `main.c` afin de garantir un accès cohérent entre threads.

`uid_msgq` transporte les UID RFID depuis `main_rfid.c` vers `uid_handler_thread()`.

`payment_msgq` transporte les demandes de paiement (plaque, prix, cause) depuis `mqtt_thread.c` vers l’UI LVGL, principalement en mode sortie. En mode entrée, un cas particulier “STOP” est aussi routé vers l’UI pour signaler un parking complet.

`payment_success_sem` est donné par `mqtt_thread.c` sur réception du topic `parking/payment/success` et débloque la validation côté interface.

`sd_lock` protège les accès FATFS à `/SD:` entre le thread MQTT et le reste de l’application.

### 6.5 Fichiers persistants sur microSD

Le projet s’appuie sur une carte microSD montée en `/SD:` afin de persister les paramètres et les droits utilisateurs entre redémarrages.

`/SD:/pin.txt` contient le PIN du mode entrée.

`/SD:/exit_pin.txt` contient le PIN du mode sortie.

`/SD:/users.txt` contient la liste des badges autorisés, au format ligne par ligne `badge:XXXXXXXX` (UID normalisé sur 8 hexadécimaux).


## 7. Installation de Zephyr et création du workspace

### 7.1 Initialisation du workspace (west)

```bash
python3 -m pip install --user west
west init zephyrproject
cd zephyrproject
west update
west zephyr-export
```

### 7.2 Toolchain : Zephyr SDK

Installer le Zephyr SDK puis suivre la section “Environment Variables” de la documentation officielle.

## 8. Configuration Zephyr du projet SysPark

Cette section documente les deux fichiers pivots du projet.

Le `prj.conf` fixe les capacités logicielles (réseau, MQTT, LVGL, SD).

L’overlay Devicetree fixe le câblage (broches, bus, périphériques).

### 8.1 prj.conf (extrait complet)

```ini
# ==========================================
#         CONFIGURATION MATÉRIELLE
# ==========================================
CONFIG_GPIO=y
CONFIG_SPI=y
CONFIG_I2C=y

# === Affichage ===
CONFIG_DISPLAY=y
CONFIG_DISPLAY_LOG_LEVEL_ERR=y
CONFIG_LVGL=y
CONFIG_LV_USE_LOG=n
CONFIG_LV_USE_LABEL=y
CONFIG_LV_USE_ARC=y
CONFIG_LV_USE_MONKEY=n
CONFIG_LV_FONT_MONTSERRAT_14=y
CONFIG_LV_FONT_MONTSERRAT_28=y
CONFIG_LV_Z_MEM_POOL_SIZE=32768
CONFIG_LV_Z_SHELL=y

# ==========================================
#             RÉSEAU (AUGMENTÉ)
# ==========================================
CONFIG_NETWORKING=y
CONFIG_NET_SOCKETS=y
CONFIG_NET_TCP=y
CONFIG_NET_LOG=y

# INDISPENSABLE POUR LA STABILITÉ MQTT
CONFIG_NET_PKT_RX_COUNT=32
CONFIG_NET_PKT_TX_COUNT=32
CONFIG_NET_BUF_RX_COUNT=64
CONFIG_NET_BUF_TX_COUNT=64

CONFIG_NET_IPV4=y
CONFIG_NET_IPV6=n
CONFIG_ETH_STM32_HAL=y
CONFIG_NET_L2_ETHERNET=y

# IP Statique
CONFIG_NET_CONFIG_SETTINGS=y
CONFIG_NET_CONFIG_NEED_IPV4=y
CONFIG_NET_CONFIG_MY_IPV4_ADDR="192.168.10.7"
#CONFIG_NET_CONFIG_MY_IPV4_ADDR="192.168.10.2"
CONFIG_NET_CONFIG_MY_IPV4_NETMASK="255.255.255.0"
CONFIG_NET_CONFIG_MY_IPV4_GW="192.168.10.1"
CONFIG_NET_CONFIG_PEER_IPV4_ADDR="192.168.10.1"
CONFIG_NET_CONFIG_INIT_TIMEOUT=5

CONFIG_MQTT_LIB=y
CONFIG_MQTT_KEEPALIVE=300

# ==========================================
#         SYSTÈME & MÉMOIRE
# ==========================================
CONFIG_ENTROPY_GENERATOR=y
CONFIG_TEST_RANDOM_GENERATOR=y
CONFIG_PRINTK=y
CONFIG_STDOUT_CONSOLE=y
CONFIG_LOG=y
CONFIG_SHELL=y
CONFIG_POSIX_API=y
CONFIG_NET_SHELL=y

CONFIG_MAIN_STACK_SIZE=12288
CONFIG_HEAP_MEM_POOL_SIZE=32768
CONFIG_REBOOT=y

# ==========================================
#         STOCKAGE (SD CARD)
# ==========================================
CONFIG_FILE_SYSTEM=y
CONFIG_FAT_FILESYSTEM_ELM=y
CONFIG_DISK_ACCESS=y
CONFIG_DISK_DRIVER_SDMMC=y
CONFIG_SDMMC_STACK=y
CONFIG_SDMMC_LOG_LEVEL_DBG=n

CONFIG_SYSTEM_WORKQUEUE_STACK_SIZE=2048
CONFIG_NET_MAX_CONN=5
```

### 8.2 Explications des choix clés du prj.conf

Les buffers réseau (`CONFIG_NET_PKT_*` et `CONFIG_NET_BUF_*`) sont volontairement augmentés pour absorber les pics de trafic et éviter les pertes lorsque la pile MQTT est active en parallèle de l’IHM et des drivers. Cette marge est particulièrement utile lors des phases de reconnexion TCP ou lorsque plusieurs publications sont rapprochées.

La pile MQTT est activée via `CONFIG_MQTT_LIB=y`, avec un keepalive à 300 s pour limiter les déconnexions intempestives dans un LAN simple, tout en conservant une détection de lien raisonnable.

La mémoire est dimensionnée pour LVGL et le réseau, via `CONFIG_MAIN_STACK_SIZE` et `CONFIG_HEAP_MEM_POOL_SIZE`, et LVGL dispose d’un pool dédié `CONFIG_LV_Z_MEM_POOL_SIZE`.

Le stockage SD est configuré en FAT via `elm-fatfs`, en s’appuyant sur SDMMC1 (voir overlay).

### 8.3 stm32f746g_disco.overlay (extrait complet)

```dts
/* boards/stm32f746g_disco.overlay */

/ {
    aliases {
        sdmmc0 = &sdmmc1;
        spi5 = &spi5;
        motor-enable = &motor_enable_pin;
        motor-step   = &motor_step_pin;
        motor-dir    = &motor_dir_pin;
        btn-rdc = &btn_rdc_pin;
        btn-1   = &btn_1_pin;
        btn-2   = &btn_2_pin;
        limit-switch = &limit_switch_pin;
    };

    motor_pins {
        compatible = "gpio-leds";
        motor_enable_pin: motor_enable_pin {
            gpios = <&gpioi 0 GPIO_ACTIVE_LOW>;
            label = "Motor Enable";
        };
        motor_step_pin: motor_step_pin {
            gpios = <&gpioi 3 GPIO_ACTIVE_HIGH>;
            label = "Motor STEP";
        };
        motor_dir_pin: motor_dir_pin {
            gpios = <&gpioh 6 GPIO_ACTIVE_HIGH>;
            label = "Motor DIR";
        };
        limit_switch_pin: limit_switch_pin {
            gpios = <&gpiog 7 (GPIO_ACTIVE_HIGH | GPIO_PULL_DOWN)>;
            label = "Limit Switch";
        };
    };

    buttons {
        compatible = "gpio-keys";
        btn_rdc_pin: btn_rdc_pin {
            gpios = <&gpioi 4 GPIO_ACTIVE_LOW>;
            label = "BTN_RDC";
            zephyr,code = <10>;
        };
        btn_1_pin: btn_1_pin {
            gpios = <&gpioc 6 GPIO_ACTIVE_LOW>;
            label = "BTN_1";
            zephyr,code = <11>;
        };
        btn_2_pin: btn_2_pin {
            gpios = <&gpioc 7 GPIO_ACTIVE_LOW>;
            label = "BTN_2";
            zephyr,code = <12>;
        };
    };
};

/* --- Carte SD --- */
&sdmmc1 {
    status = "okay";
    pinctrl-0 = <&sdmmc1_d0_pc8 &sdmmc1_d1_pc9 &sdmmc1_d2_pc10 &sdmmc1_d3_pc11 &sdmmc1_ck_pc12 &sdmmc1_cmd_pd2>;
    pinctrl-names = "default";
    bus-width = <4>;
    cd-gpios = <&gpioi 15 GPIO_ACTIVE_LOW>;
};

/* --- SPI2 PARTAGÉ : TMC5160 + RC522 --- */
&spi2 {
    status = "okay";
    pinctrl-0 = <&spi2_sck_pi1 &spi2_miso_pb14 &spi2_mosi_pb15>;
    pinctrl-names = "default";

    cs-gpios = <&gpioa 8 GPIO_ACTIVE_LOW>, <&gpioa 15 GPIO_ACTIVE_LOW>;

    tmc5160: tmc5160@0 {
        compatible = "vnd,spi-device";
        reg = <1>;
        spi-max-frequency = <1000000>;
        label = "TMC5160";
    };

    rc522: rc522@1 {
        compatible = "vnd,spi-device";
        reg = <0>;
        spi-max-frequency = <4000000>;
        label = "RC522";
    };
};

/* --- Ethernet --- */
&mac { status = "okay"; phy-handle = <&phy0>; };
&mdio { status = "okay"; phy0: ethernet-phy@0 { reg = <0>; }; };

/* --- SPI5 pour OLED --- */
&spi5 {
    status = "okay";
    pinctrl-0 = <&spi5_sck_pf7 &spi5_mosi_pf9>;
    pinctrl-names = "default";

    oled: oled@0 {
        compatible = "vnd,spi-device";
        reg = <0>;
        spi-max-frequency = <4000000>;
        label = "OLED";
    };
};

/* Activation des ports GPIO */
&gpioa { status = "okay"; label = "GPIOA"; };
&gpioc { status = "okay"; };
&gpiof { status = "okay"; label = "GPIOF"; };
&gpiog { status = "okay"; };
&gpioh { status = "okay"; };
&gpioi { status = "okay"; };
&i2c1 { status = "okay"; };
```

### 8.4 Explications des points sensibles de l’overlay

Les alias `motor-enable`, `motor-step`, `motor-dir`, `limit-switch` permettent d’accéder proprement aux GPIO depuis le code (via `DT_ALIAS(...)`) sans dépendre de noms de nœuds variables.

Le nœud `gpio-leds` est ici utilisé comme un conteneur pratique pour déclarer des GPIO “nommés” et récupérables via Devicetree.

Sur SPI2, la paire `cs-gpios` expose deux lignes CS. La configuration effective est.

RC522 utilise `reg = <0>` donc CS index 0 donc PA8.

TMC5160 utilise `reg = <1>` donc CS index 1 donc PA15.

L’Ethernet est explicitement activé via `&mac` et `&mdio`, avec un PHY à l’adresse 0.

La carte SD est activée en mode 4 bits et avec card detect sur PI15.

## 9. Architecture logicielle recommandée (référence)

Cette section sert de guide de conception pour structurer l’application SysPark dans `src/`. Elle n’impose pas un nom de fichier particulier, mais décrit une organisation qui facilite le debug terrain et la robustesse.

### 9.1 Boucle principale et machine d’états

Le cœur applicatif est idéalement modélisé comme une machine d’états, pilotée par des événements.

Événements matériels : badge RFID lu, appui bouton, fin de course atteint, timeout sécurité.

Événements réseau : commande MQTT reçue, perte de session TCP, reconnexion.

L’intérêt est d’éviter un enchaînement de delays bloquants qui “gèle” le réseau. Les séquences moteur doivent être non bloquantes (timer, thread dédié, ou workqueue), afin que la pile TCP/MQTT conserve du temps CPU et que le shell réseau reste réactif.

### 9.2 Threads, timers et workqueue

Une répartition pratique, adaptée à Zephyr.

Un thread réseau MQTT, gérant l’établissement de connexion, les keepalive, et la livraison des messages entrants.

Un thread moteur, responsable de générer STEP/DIR et d’appliquer les interverrouillages de sécurité (fin de course, arrêt d’urgence logiciel).

Un timer périodique de “heartbeat” (publication d’état), utile pour le monitoring et la supervision côté BeagleY‑AI.

Un usage prudent de la system workqueue pour les actions rapides (mise à jour affichage, écriture SD), en évitant d’y mettre une génération de pulses STEP.

### 9.3 Pilotage moteur : principes de sécurité

La sortie `Motor Enable` étant Active LOW, une règle simple est de démarrer avec ENABLE inactif (désactivation) puis n’activer le driver que lorsque l’état applicatif est prêt et que l’environnement est connu.

Le fin de course doit être considéré comme un signal de sécurité. Une fois déclenché, la commande moteur doit forcer un arrêt et un changement d’état, même si une commande MQTT demande l’inverse. Le réseau ne doit jamais pouvoir violer les interlocks physiques.

### 9.4 RFID : stratégie de publication MQTT

La publication d’un UID RFID peut être faite en clair (pour debug), mais en exploitation il est recommandé d’émettre au minimum un identifiant normalisé (hex), et d’éviter de “spammer” le broker en répétant le même UID à haute fréquence. Une fenêtre anti‑rebond logique (cooldown) est utile.

### 9.5 Affichage et LVGL

LVGL apporte une UI plus riche, mais augmente la pression mémoire. Dans votre `prj.conf`, la mémoire LVGL est déjà dimensionnée via `CONFIG_LV_Z_MEM_POOL_SIZE=32768` et le heap global. Le point critique est de maintenir une boucle LVGL régulière (tick + handler) sans bloquer le réseau.

### 9.6 Stockage SD (FAT)

Avec SDMMC1 + FAT, la SD peut être utilisée pour des logs terrain. Le design recommandé est d’écrire des événements structurés (timestamp, type, valeur) et de ne jamais écrire en boucle rapide (risque d’usure et de latence). Une stratégie de buffer (RAM) + flush périodique est plus robuste.

## 10. Compilation et flashage

Depuis la racine du workspace Zephyr (dossier `zephyr/`) :

```bash
west build -p always -b stm32f746g_disco samples/net/mqtt_publisher
```

Pour flasher via le ST‑LINK intégré (CN14) :

```bash
west flash
```

Si votre environnement impose explicitement STM32CubeProgrammer :

```bash
west flash --runner stm32cubeprogrammer
```

## 11. Configuration réseau SysPark

Le projet est configuré en IPv4 statique, afin de simplifier l’intégration avec la passerelle BeagleY‑AI.

Adresse STM32 : 192.168.10.7

Masque : 255.255.255.0

Passerelle : 192.168.10.1

Ces valeurs se modifient dans `prj.conf` via `CONFIG_NET_CONFIG_MY_IPV4_ADDR`, `CONFIG_NET_CONFIG_MY_IPV4_GW`, etc.

## 12. MQTT : intégration avec la BeagleY‑AI

Le STM32 agit comme client MQTT sur Ethernet. La BeagleY‑AI héberge typiquement un broker local et éventuellement un pont vers le cloud. Les topics exacts doivent être strictement alignés avec la taxonomie SysPark côté passerelle.

Recommandation d’intégration (à adapter à votre code) :

| Sens | Topic | Payload | Rôle |
|---|---|---|---|
| STM32 → Beagle | `parking/rfid/uid` | UID badge | Identification locale |
| STM32 → Beagle | `parking/gate/state` | état barrière | Etat actionneur |
| STM32 → Beagle | `parking/gate/limit` | 0/1 | Fin de course |
| Beagle → STM32 | `parking/gate/cmd` | OUVRIR/FERMER | Commandes |

## 13. Dépannage

### 12.1 MQTT “Connection refused” (-111)

Vérifier l’Ethernet, puis la disponibilité du broker MQTT sur l’adresse attendue.

Vérifier que le port MQTT (souvent 1883 en local) est accessible.

### 12.2 Moteur ou RFID inactifs

Revalider la correspondance des broches CS (PA8, PA15) et l’absence de conflit de câblage lié aux labels Arduino, en vous référant à l’overlay.

### 12.3 OLED noir

Revalider que l’écran est câblé sur SPI5 (PF7/PF9). Vérifier le dimensionnement mémoire LVGL (`CONFIG_LV_Z_MEM_POOL_SIZE`) et la fréquence SPI.
