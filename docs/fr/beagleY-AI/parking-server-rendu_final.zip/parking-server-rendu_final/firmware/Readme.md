# 🅿️ Sous-Ensemble : Contrôleur Principal (STM32F746G-DISCO & Zephyr OS)

Ce dossier contient le firmware du contrôleur central du système **Parking Monitoring System**. Il est développé sous **Zephyr RTOS** et s'exécute sur une carte **STM32F746G-DISCO**.

Ce module agit comme le cerveau local du parking. Il gère l'interface utilisateur tactile, le contrôle temps réel de l'ascenseur à voitures, la lecture des badges d'accès et la communication réseau avec le serveur central.

## 📋 Fonctionnalités Validées

### 1. Contrôle d'Accès & Paiement
* **Lecture RFID (RC522) :** Détection des badges 13.56 MHz via bus SPI.
* **Authentification :** Vérification locale (liste blanche sur carte SD) et distante (requête serveur via MQTT).
* **Paiement :** Affichage d'un QR Code dynamique sur l'écran tactile pour le paiement. Validation via MQTT.
* **Codes PIN :** Clavier virtuel sécurisé (LVGL) pour l'entrée et la sortie de secours.

### 2. Pilotage Ascenseur (Temps Réel)
* **Moteur Pas-à-pas :** Contrôle précis d'un NEMA17 via un driver **TMC5160** en SPI.
* **Mouvements :** Gestion des rampes d'accélération/décélération et positionnement absolu (microstepping 1/16).
* **Calibration (Homing) :** Procédure automatique de recherche du point zéro (RDC) au démarrage via capteur fin de course.
* **Sécurité :** Redémarrage automatique du driver en cas de coupure d'alimentation moteur (Surveillance registre `GSTAT`).

### 3. Interface Homme-Machine (IHM)
* **Écran Tactile (LVGL) :** Interface graphique pour le statut du parking, le clavier numérique et les interactions utilisateur.
* **Écran OLED (SPI) :** Affichage dédié en temps réel de l'étage et de la direction de l'ascenseur.
* **Écran LCD 20x4 (I2C) :** Affichage des places disponibles et des données environnementales (Météo, CO2).

### 4. Connectivité & Système
* **Réseau :** Stack TCP/IP complète sur Ethernet (IP Statique : `192.168.10.2`).
* **Protocole :** Client MQTT asynchrone pour la télémétrie et le contrôle.
* **Stockage :** Gestion d'une carte SD (FATFS) pour la persistance des configurations (PINs) et des utilisateurs.

---

## 🛠 Matériel et Brochage (Pinout)

Le système repose sur le bus Arduino UNO et les connecteurs d'extension de la carte Disco.

### 🔌 Bus de Communication
| Bus | Usage | Périphériques Connectés |
| :--- | :--- | :--- |
| **SPI2** | Bus Partagé | Driver Moteur TMC5160 + Lecteur RFID RC522 |
| **SPI5** | Affichage | Écran OLED SH1106 |
| **I2C1** | Affichage | Écran LCD 20x4 |
| **SDMMC1** | Stockage | Carte MicroSD |
| **Ethernet** | Réseau | Port RJ45 natif |

### 📍 Table de Connexion GPIO

**1. Ascenseur (Moteur & Capteurs)**
| Signal | Pin STM32 | Rôle |
| :--- | :--- | :--- |
| **SPI2_SCK** | PI1 | Horloge SPI |
| **SPI2_MISO** | PB14 | Données In |
| **SPI2_MOSI** | PB15 | Données Out |
| **CS_TMC5160** | **PA15** | Chip Select Driver |
| **ENABLE** | **PI0** | Activation Moteur |
| **STEP** | **PI3** | Impulsion de pas |
| **DIR** | **PH6** | Direction |
| **LIMIT_SW** | **PG7** | Fin de course RDC (Pull-Down) |
| **BTN_RDC** | PI4 | Appel RDC |
| **BTN_1** | PC6 | Appel Étage 1 |
| **BTN_2** | PC7 | Appel Étage 2 |

**2. Lecteur RFID (RC522)**
| Signal | Pin STM32 | Rôle |
| :--- | :--- | :--- |
| **CS_RC522** | **PA8** | Chip Select RFID |
| **RST_RC522** | **PG6** | Reset Hardware |

**3. Écran OLED (SH1106)**
| Signal | Pin STM32 | Rôle |
| :--- | :--- | :--- |
| **SPI5_SCK** | PF7 | Horloge |
| **SPI5_MOSI** | PF9 | Données |
| **CS_OLED** | **PF6** | Chip Select |
| **DC** | PF10 | Data/Command |
| **RES** | PA0 | Reset |

---

## 🏗 Architecture Logicielle

Le firmware utilise une architecture multi-threadée pour garantir la réactivité du système, même lors des mouvements de l'ascenseur.

### Diagramme des Threads
* **Main Thread (`main.c`)** : Gestion de l'UI LVGL, tactile, lecture des files de messages (Paiement) et gestion de l'écran de veille.
* **Elevator Thread (`ascenseur_controle.c`)** : Thread haute priorité. Gère la machine à état, le homing et les commandes SPI temps réel vers le TMC5160.
* **MQTT Thread (`mqtt_thread.c`)** : Gère la connexion réseau, les abonnements, et dispatch les messages reçus vers les autres modules (LCD, Ascenseur).
* **RFID Thread (`main_rfid.c`)** : Polling continu du lecteur RC522. Envoie les UIDs détectés dans une queue de message vers le thread MQTT.
* **Display Threads** : Threads dédiés pour le rafraîchissement de l'OLED (`oled_thread.c`) et du LCD (`lcd_display.c`).

---

## 🚀 Instructions de Build & Flash

### Prérequis
* Zephyr SDK 0.17+
* West & Ninja

### Commandes
1.  **Compilation (Build)** :
    ```bash
    west build -b stm32f746g_disco --pristine
    ```

2.  **Flashage** (Via ST-Link V2-1 embarqué) :
    ```bash
    west flash
    ```

3.  **Logs Série** (Pour le débug) :
    Connexion via le port USB ST-Link (115200 bauds).
    ```bash
    minicom -D /dev/ttyACM0
    ```

---

## 📡 API MQTT

Le système communique via les topics suivants :

### Publications (STM32 → Serveur)
* `parking/barriere` : Envoi de l'UID du badge scanné.
* `parking/ascenseur/state` : État courant de l'ascenseur (JSON : `{"current": 1}`).
* `parking/acl/list` : Liste complète des accès autorisés (cache local).
* `parking/acl/event` : Confirmation d'ajout/suppression de badge.

### Souscriptions (Serveur → STM32)
* `parking/ascenseur/cmd` : Commande de déplacement (`RDC`, `ETAGE1`, `ETAGE2`).
* `parking/config/pin` & `exit_pin` : Mise à jour des codes d'accès à distance.
* `parking/payment/req` : Demande d'affichage du QR Code de paiement (JSON : Plaque, Prix).
* `parking/payment/success` : Validation du paiement (Ouvre la barrière/Ferme le popup).
* `parking/meteo` : Données météo pour l'écran LCD.
* `parking/display/text` : Mise à jour du nombre de places libres sur le LCD.